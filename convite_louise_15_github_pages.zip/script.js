const target = new Date("2026-10-03T14:00:00-03:00").getTime();

function updateCountdown(){
  const diff = Math.max(0, target - Date.now());
  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff % 86400000) / 3600000);
  const minutes = Math.floor((diff % 3600000) / 60000);
  const seconds = Math.floor((diff % 60000) / 1000);
  document.getElementById("days").textContent = String(days).padStart(2,"0");
  document.getElementById("hours").textContent = String(hours).padStart(2,"0");
  document.getElementById("minutes").textContent = String(minutes).padStart(2,"0");
  document.getElementById("seconds").textContent = String(seconds).padStart(2,"0");
}
updateCountdown();
setInterval(updateCountdown,1000);

function downloadCalendar(){
  const ics = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Louise 15 Anos//PT-BR",
    "BEGIN:VEVENT",
    "UID:louise-15-20261003@convite",
    "DTSTAMP:20260825T000000Z",
    "DTSTART:20261003T140000",
    "SUMMARY:15 anos da Louise Victória",
    "LOCATION:Rancho Xavier, Rua Toca do Coelho",
    "DESCRIPTION:Uma nova Jornada se inicia... Pool Party dos 15 anos de Louise Victória.",
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");
  const blob = new Blob([ics],{type:"text/calendar;charset=utf-8"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href=url; a.download="louise-15-anos.ics"; a.click();
  URL.revokeObjectURL(url);
}
